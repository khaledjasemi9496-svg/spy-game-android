package com.example.spygame

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random

private val Night = Color(0xFF090B14)
private val Panel = Color(0xFF151A2B)
private val Panel2 = Color(0xFF1D2438)
private val Violet = Color(0xFF9B7BFF)
private val Cyan = Color(0xFF54D6D0)
private val Muted = Color(0xFF9AA4BC)
private val White = Color(0xFFF4F3FA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SpyApp() }
    }
}

private data class WordCard(val category: String, val word: String)
private val wordBank = listOf(
    WordCard("أماكن", "المطار"), WordCard("أماكن", "المستشفى"),
    WordCard("أماكن", "مدينة الملاهي"), WordCard("أماكن", "المتحف"),
    WordCard("أماكن", "الشاطئ"), WordCard("أماكن", "محطة القطار"),
    WordCard("أكلات", "البيتزا"), WordCard("أكلات", "الكبسة"),
    WordCard("أكلات", "السوشي"), WordCard("أكلات", "الآيس كريم"),
    WordCard("أكلات", "الفشار"), WordCard("أكلات", "الفطائر"),
    WordCard("حيوانات", "الفيل"), WordCard("حيوانات", "البطريق"),
    WordCard("حيوانات", "الزرافة"), WordCard("حيوانات", "الدلفين"),
    WordCard("حيوانات", "النمر"), WordCard("حيوانات", "الأرنب"),
    WordCard("أشياء", "المظلة"), WordCard("أشياء", "الكاميرا"),
    WordCard("أشياء", "الحاسوب"), WordCard("أشياء", "الساعة"),
    WordCard("أشياء", "النظارة"), WordCard("أشياء", "المصباح"),
    WordCard("مهن", "الطبيب"), WordCard("مهن", "المصور"),
    WordCard("مهن", "الطيار"), WordCard("مهن", "المعلم"),
    WordCard("مهن", "المهندس"), WordCard("مهن", "الطاهي")
)

private enum class Screen { SETUP, REVEAL, DISCUSS, VOTE, RESULT }

@Composable
private fun SpyApp() {
    var names by remember { mutableStateOf(listOf("خالد", "جاسم", "يوسف", "عيسى", "خالد الشيخ")) }
    var draft by remember { mutableStateOf("") }
    var spyCount by remember { mutableIntStateOf(1) }
    var category by remember { mutableStateOf("الكل") }
    var screen by remember { mutableStateOf(Screen.SETUP) }
    var word by remember { mutableStateOf(wordBank.random()) }
    var spies by remember { mutableStateOf(setOf<Int>()) }
    var current by remember { mutableIntStateOf(0) }
    var shown by remember { mutableStateOf(false) }
    var votes by remember { mutableStateOf(List(names.size) { -1 }) }
    var voteIndex by remember { mutableIntStateOf(0) }
    var resultText by remember { mutableStateOf("") }

    fun startRound() {
        val pool = if (category == "الكل") wordBank else wordBank.filter { it.category == category }
        word = pool.random()
        spies = (names.indices).shuffled().take(spyCount).toSet()
        current = 0
        shown = false
        votes = List(names.size) { -1 }
        voteIndex = 0
        resultText = ""
        screen = Screen.REVEAL
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Night, surface = Panel, primary = Violet,
            secondary = Cyan, onBackground = White, onSurface = White
        )
    ) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF17152C), Night, Color(0xFF080A10)))
            )
        ) {
            Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 18.dp)) {
                Header()
                Spacer(Modifier.height(22.dp))
                when (screen) {
                    Screen.SETUP -> SetupScreen(
                        names, { names = it }, draft, { draft = it }, spyCount,
                        { spyCount = it }, category, { category = it }, ::startRound
                    )
                    Screen.REVEAL -> RevealScreen(
                        names[current], current + 1, names.size, shown,
                        spies.contains(current), word, {
                            shown = !shown
                        }, {
                            shown = false
                            if (current < names.lastIndex) current++ else screen = Screen.DISCUSS
                        }
                    )
                    Screen.DISCUSS -> DiscussScreen(names.size, { screen = Screen.VOTE; voteIndex = 0 })
                    Screen.VOTE -> VoteScreen(
                        names, voteIndex, votes[voteIndex], { selected ->
                            votes = votes.toMutableList().also { it[voteIndex] = selected }
                        }, {
                            if (voteIndex < names.lastIndex) voteIndex++ else {
                                val counts = names.indices.associateWith { i -> votes.count { it == i } }
                                val highest = counts.values.maxOrNull() ?: 0
                                val accused = counts.filterValues { it == highest }.keys
                                resultText = if (accused.size != 1) "التصويت متعادل! لم يتم تحديد مشتبه به."
                                else if (spies.contains(accused.first())) "أحسنتم! تم كشف الجاسوس."
                                else "لم يتم كشف الجاسوس هذه المرة."
                                screen = Screen.RESULT
                            }
                        }
                    )
                    Screen.RESULT -> ResultScreen(
                        resultText, names.filterIndexed { i, _ -> spies.contains(i) },
                        word, { screen = Screen.SETUP }, { startRound() }
                    )
                }
                Spacer(Modifier.height(12.dp))
                Text("تعمل بدون إنترنت • مرّروا الجهاز بين اللاعبين", color = Muted, fontSize = 11.sp,
                    modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
private fun Header() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(46.dp).background(
                Brush.linearGradient(listOf(Violet, Color(0xFF4B3A8C))), RoundedCornerShape(15.dp)
            ), contentAlignment = Alignment.Center
        ) { Text("◈", color = White, fontSize = 27.sp, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.width(12.dp))
        Column {
            Text("لعبة الجاسوس", color = White, fontSize = 22.sp, fontWeight = FontWeight.Black)
            Text("مهمتك أن تكشفه… أو ألا تُكشف", color = Muted, fontSize = 11.sp)
        }
        Spacer(Modifier.weight(1f))
        Box(Modifier.border(1.dp, Violet.copy(alpha = .5f), CircleShape).padding(horizontal = 11.dp, vertical = 7.dp)) {
            Text("OFFLINE", color = Cyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SetupScreen(
    names: List<String>, onNames: (List<String>) -> Unit, draft: String, onDraft: (String) -> Unit,
    spyCount: Int, onSpyCount: (Int) -> Unit, category: String, onCategory: (String) -> Unit,
    onStart: () -> Unit
) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("جهّزوا الجولة", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("أضيفوا اللاعبين، ثم مرّروا الجهاز ليعرف كل لاعب دوره بسرية.", color = Muted, fontSize = 13.sp)
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Label("اللاعبون  •  ${names.size}")
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = draft, onValueChange = onDraft, modifier = Modifier.weight(1f),
                        placeholder = { Text("اسم اللاعب", color = Muted) }, singleLine = true,
                        colors = fieldColors()
                    )
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = {
                        val n = draft.trim()
                        if (n.isNotEmpty() && names.size < 12 && n !in names) {
                            onNames(names + n); onDraft("")
                        }
                    }, enabled = draft.trim().isNotEmpty() && names.size < 12,
                        colors = ButtonDefaults.buttonColors(containerColor = Violet),
                        contentPadding = PaddingValues(horizontal = 15.dp, vertical = 16.dp)
                    ) { Text("إضافة") }
                }
                names.forEachIndexed { i, n ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(29.dp).background(Panel2, CircleShape), contentAlignment = Alignment.Center) {
                            Text("${i + 1}", color = Cyan, fontSize = 12.sp)
                        }
                        Spacer(Modifier.width(10.dp))
                        Text(n, color = White, modifier = Modifier.weight(1f), fontSize = 14.sp)
                        Text("حذف", color = Color(0xFFFF8D9A), fontSize = 12.sp,
                            modifier = Modifier.clickable { if (names.size > 3) onNames(names.filterIndexed { ix, _ -> ix != i }) })
                    }
                }
                Text("يمكن اللعب من 3 إلى 12 لاعباً", color = Muted, fontSize = 10.sp)
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
                Label("إعدادات الجولة")
                Text("عدد الجواسيس", color = Muted, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    (1..minOf(3, names.size - 2)).forEach { count ->
                        ChoiceChip("$count", spyCount == count) { onSpyCount(count) }
                    }
                }
                Text("فئة الكلمات", color = Muted, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    listOf("الكل", "أماكن", "أكلات", "حيوانات").forEach {
                        ChoiceChip(it, category == it) { onCategory(it) }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    listOf("أشياء", "مهن").forEach {
                        ChoiceChip(it, category == it) { onCategory(it) }
                    }
                }
            }
        }
        Button(
            onClick = onStart, enabled = names.size >= 3 && spyCount < names.size - 1,
            modifier = Modifier.fillMaxWidth().height(54.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Violet),
            shape = RoundedCornerShape(16.dp)
        ) { Text("ابدأ الجولة  →", fontSize = 16.sp, fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun RevealScreen(
    name: String, number: Int, total: Int, shown: Boolean, isSpy: Boolean, word: WordCard,
    toggle: () -> Unit, next: () -> Unit
) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(15.dp)) {
        StepTag("المرحلة 01  /  توزيع الأدوار")
        Text("مرّر الجهاز إلى", color = Muted, fontSize = 14.sp)
        Text(name, color = White, fontSize = 31.sp, fontWeight = FontWeight.Black)
        Row(verticalAlignment = Alignment.CenterVertically) {
            repeat(total) { i ->
                Box(Modifier.weight(1f).height(4.dp).padding(end = 4.dp)
                    .background(if (i < number) Violet else Panel2, RoundedCornerShape(5.dp)))
            }
        }
        Card(
            modifier = Modifier.fillMaxWidth().height(220.dp).clickable { toggle() },
            colors = CardDefaults.cardColors(containerColor = Panel),
            shape = RoundedCornerShape(24.dp)
        ) {
            Box(Modifier.fillMaxSize().padding(20.dp), contentAlignment = Alignment.Center) {
                if (!shown) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("◉", color = Violet, fontSize = 45.sp)
                        Text("اضغط لكشف دورك", color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("تأكد أن لا أحد ينظر إلى الشاشة", color = Muted, fontSize = 12.sp)
                    }
                } else {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(if (isSpy) "مهمتك السرية" else "الكلمة السرية", color = Muted, fontSize = 13.sp)
                        Text(if (isSpy) "أنت الجاسوس" else word.word, color = if (isSpy) Color(0xFFFF899A) else Cyan,
                            fontSize = 29.sp, fontWeight = FontWeight.Black)
                        Text(if (isSpy) "حاول اكتشاف الكلمة دون أن تنكشف" else "الفئة: ${word.category}",
                            color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
                    }
                }
            }
        }
        if (shown) {
            Button(onClick = next, modifier = Modifier.fillMaxWidth().height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Violet), shape = RoundedCornerShape(15.dp)) {
                Text(if (number < total) "إخفاء والمتابعة للاعب التالي" else "انتهاء التوزيع")
            }
        } else {
            Text("تذكير: بعد مشاهدة دورك، أخفِ الشاشة قبل تمرير الجهاز.", color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun DiscussScreen(total: Int, onVote: () -> Unit) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        StepTag("المرحلة 02  /  النقاش")
        Text("ابدؤوا التحقيق", color = White, fontSize = 29.sp, fontWeight = FontWeight.Black)
        Text("اسألوا بعضكم أسئلة ذكية عن الكلمة. لا تذكروا الكلمة نفسها، وحاولوا اكتشاف من لا يعرفها.", color = Muted, fontSize = 14.sp, lineHeight = 23.sp)
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Label("قواعد سريعة")
                Text("• كل لاعب يجيب دون كشف الكلمة مباشرة\n• الجاسوس يحاول الاندماج مع المجموعة\n• اتفقوا متى ينتهي النقاش", color = White, lineHeight = 25.sp, fontSize = 13.sp)
            }
        }
        Button(onClick = onVote, modifier = Modifier.fillMaxWidth().height(54.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Violet), shape = RoundedCornerShape(16.dp)) {
            Text("انتقلوا إلى التصويت")
        }
    }
}

@Composable
private fun VoteScreen(
    names: List<String>, voter: Int, selected: Int, onSelect: (Int) -> Unit, next: () -> Unit
) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        StepTag("المرحلة 03  /  التصويت")
        Text("من تشكّون بأنه الجاسوس؟", color = White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("صوّتوا بالتتابع. لا تصوّت لنفسك: ${names[voter]}", color = Muted, fontSize = 12.sp)
        Text("تصويت اللاعب ${voter + 1} من ${names.size}", color = Cyan, fontSize = 12.sp)
        names.forEachIndexed { i, n ->
            if (i != voter) {
                Row(
                    Modifier.fillMaxWidth().background(if (selected == i) Color(0xFF30294C) else Panel, RoundedCornerShape(14.dp))
                        .border(1.dp, if (selected == i) Violet else Color.Transparent, RoundedCornerShape(14.dp))
                        .clickable { onSelect(i) }.padding(15.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(n, color = White, modifier = Modifier.weight(1f))
                    RadioButton(selected == i, onClick = { onSelect(i) }, colors = RadioButtonDefaults.colors(selectedColor = Violet))
                }
            }
        }
        Button(onClick = next, enabled = selected >= 0, modifier = Modifier.fillMaxWidth().height(52.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Violet), shape = RoundedCornerShape(15.dp)) {
            Text(if (voter == names.lastIndex) "اعتماد الأصوات" else "تأكيد ومتابعة")
        }
    }
}

@Composable
private fun ResultScreen(message: String, spies: List<String>, word: WordCard, home: () -> Unit, again: () -> Unit) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        StepTag("المرحلة 04  /  النتيجة")
        Text("انتهت الجولة", color = White, fontSize = 30.sp, fontWeight = FontWeight.Black)
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("✦", color = Violet, fontSize = 40.sp)
                Text(message, color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Label("الجاسوس")
                Text(spies.joinToString("، "), color = Color(0xFFFF899A), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Label("الكلمة الصحيحة")
                Text(word.word, color = Cyan, fontSize = 25.sp, fontWeight = FontWeight.Black)
                Text("الفئة: ${word.category}", color = Muted, fontSize = 12.sp)
            }
        }
        Button(onClick = again, modifier = Modifier.fillMaxWidth().height(52.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Violet), shape = RoundedCornerShape(15.dp)) { Text("جولة جديدة") }
        OutlinedButton(onClick = home, modifier = Modifier.fillMaxWidth().height(50.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = White)) { Text("العودة للإعدادات") }
    }
}

@Composable
private fun Label(value: String) {
    Text(value, color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
}
@Composable
private fun StepTag(value: String) {
    Text(value, color = Violet, fontSize = 11.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.background(Violet.copy(alpha = .12f), RoundedCornerShape(20.dp)).padding(horizontal = 12.dp, vertical = 8.dp))
}
@Composable
private fun ChoiceChip(value: String, selected: Boolean, onClick: () -> Unit) {
    Box(Modifier.background(if (selected) Violet.copy(alpha = .25f) else Panel2, RoundedCornerShape(50))
        .border(1.dp, if (selected) Violet else Color.Transparent, RoundedCornerShape(50))
        .clickable { onClick() }.padding(horizontal = 13.dp, vertical = 9.dp)) {
        Text(value, color = if (selected) White else Muted, fontSize = 12.sp)
    }
}
@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = White, unfocusedTextColor = White,
    focusedBorderColor = Violet, unfocusedBorderColor = Panel2,
    cursorColor = Cyan, focusedPlaceholderColor = Muted, unfocusedPlaceholderColor = Muted
)
